
                <li class="panel">
                    <a href="index.php?m=contents&p=home">
                        <i class="icon-home"></i> Dashboard
                    </a>                   
                </li>
				
				<li class="panel">
                    <a href="index.php?m=contents&p=profit">
                        <i class="icon-bar-chart"></i> Profit
                    </a>                   
                </li>	

				<li class="panel">
                    <a href="index.php?m=contents&p=cek-transfer">
                        <i class="icon-check"></i> Cek Transfer
                    </a>                   
                </li>
				
				<li class="panel">
                    <a href="index.php?m=contents&p=view-pembayaran">
                        <i class="icon-dollar"></i> &nbsp;Pembayaran
                    </a>                   
                </li>

				<li class="panel">
                    <a href="index.php?m=contents&p=input-pengeluaran">
                        <i class="icon-share"></i> Pengeluaran
                    </a>                   
                </li>
				
                <li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#keuangan-nav">
                        <i class="icon-money"> </i> Data Keuangan     
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-primary">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="keuangan-nav">  
                        <li class=""><a href="index.php?m=contents&p=pemasukan"><i class="icon-angle-right"></i> Data Pemasukan </a></li>
                        <li class=""><a href="index.php?m=contents&p=pengeluaran"><i class="icon-angle-right"></i> Data Pengeluaran </a></li>
                    </ul>
                </li>
							
				
             	<li class="panel">
                    <a href="index.php?m=contents&p=laporan">
                        <i class="icon-file"></i> &nbsp;Laporan
                    </a>                   
                </li>			
				
             	<li class="panel">
                    <a href="index.php?m=contents&p=agenda">
                        <i class="icon-calendar"></i> Agenda & Kegiatan
                    </a>                   
                </li>             

				<li class="panel">
                    <a href="index.php?m=contents&p=album">
                        <i class="icon-picture"></i> Galeri Foto
                    </a>                   
                </li>
				
                <li class="panel ">
                    <a href="#" data-parent="#menu" data-toggle="collapse" class="accordion-toggle" data-target="#br-nav">
                        <i class="icon-briefcase"> </i> Backup & Restore     
	   
                        <span class="pull-right">
                          <i class="icon-angle-left"></i>
                        </span>
                       &nbsp; <span class="label label-primary">2</span>&nbsp;
                    </a>
                    <ul class="collapse" id="br-nav">  
                        <li class=""><a href="index.php?m=contents&p=backup"><i class="icon-angle-right"></i> Backup </a></li>
                        <li class=""><a href="index.php?m=contents&p=restore"><i class="icon-angle-right"></i> Restore </a></li>
                    </ul>
                </li>