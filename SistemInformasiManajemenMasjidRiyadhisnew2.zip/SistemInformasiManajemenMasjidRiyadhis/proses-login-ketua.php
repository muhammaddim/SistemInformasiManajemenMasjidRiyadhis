<?php
include "koneksidb.php";
session_start();

if (isset($_POST["LoginKetua"])) {
    $user = $mysqli->escape_string($_POST["username"]);
    $pass = $mysqli->escape_string($_POST["password"]);

    $sql = "SELECT * FROM tbl_ketua WHERE user_id='$user'";
    $res = $mysqli->query($sql);

    if (!$res) {
        die("Query Error: " . $mysqli->error);
    }

    if (mysqli_num_rows($res) === 1) {
        $data = mysqli_fetch_assoc($res);

        // ✅ Verifikasi password HASH (cocok dengan database kamu)
        if (password_verify($pass, $data["password"])) {
            $_SESSION["id_ketua"]     = $data["id_ketua"];
            $_SESSION["user_id"]      = $data["user_id"];
            $_SESSION["nama_ketua"]   = $data["nama_lengkap"];
            header("Location: ketua/index.php");
            exit();
        } else {
            echo "<script>alert('Password salah!'); window.location.href='administrator.php?tab=ketua';</script>";
        }
    } else {
        echo "<script>alert('Username tidak ditemukan!'); window.location.href='administrator.php';</script>";
    }
}
?>
