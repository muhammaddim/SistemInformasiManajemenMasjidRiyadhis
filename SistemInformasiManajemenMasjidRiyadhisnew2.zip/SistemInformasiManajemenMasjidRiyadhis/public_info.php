<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_masjid";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to get donation categories and their totals
function getDonationCategories($conn) {
    $categories = array();
    $sql = "SELECT k.id_kategori, k.nama_kategori, d.total 
            FROM tbl_kategori k
            JOIN tbl_dana d ON k.id_kategori = d.id_kategori
            ORDER BY k.nama_kategori";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    return $categories;
}

// Function to get upcoming events/agenda
function getUpcomingEvents($conn) {
    $events = array();
    $sql = "SELECT a.judul, a.tgl_awal, a.tgl_akhir, a.jam_awal, a.jam_akhir, a.keterangan, p.nama as nama_petugas 
            FROM tbl_agenda a
            JOIN tbl_petugas p ON a.id_petugas = p.id_petugas
            WHERE a.tgl_akhir >= CURDATE()
            ORDER BY a.tgl_awal ASC
            LIMIT 5";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
    }
    return $events;
}

// Function to get photo gallery
function getPhotoGallery($conn) {
    $photos = array();
    $sql = "SELECT a.file_name, a.tgl_upload, p.nama as uploader 
            FROM tbl_album a
            JOIN tbl_petugas p ON a.id_petugas = p.id_petugas
            ORDER BY a.tgl_upload DESC
            LIMIT 6";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $photos[] = $row;
        }
    }
    return $photos;
}

// Get data
$categories = getDonationCategories($conn);
$events = getUpcomingEvents($conn);
$photos = getPhotoGallery($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi Masjid</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .header {
            background-color: #075e54;
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            text-align: center;
        }
        .card {
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: none;
        }
        .card-header {
            background-color: #075e54;
            color: white;
            font-weight: bold;
        }
        .donation-category {
            border-left: 4px solid #075e54;
            padding-left: 10px;
            margin-bottom: 10px;
        }
        .event-item {
            border-bottom: 1px solid #e9ecef;
            padding: 10px 0;
        }
        .event-item:last-child {
            border-bottom: none;
        }
        .photo-gallery img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        .footer {
            background-color: #075e54;
            color: white;
            padding: 1.5rem 0;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="container">
            <h1><i class="fas fa-mosque"></i> Informasi Masjid</h1>
            <p>Menyediakan informasi terkait kegiatan dan dana masjid</p>
        </div>
    </div>
    
    <div class="container">
        <div class="row">
            <!-- Dana Masjid -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-hand-holding-usd"></i> Dana Masjid
                    </div>
                    <div class="card-body">
                        <?php if (count($categories) > 0): ?>
                            <?php foreach($categories as $category): ?>
                                <div class="donation-category">
                                    <h5><?php echo htmlspecialchars($category["nama_kategori"]); ?></h5>
                                    <p>Total Dana: <strong>Rp <?php echo number_format($category["total"], 0, ',', '.'); ?></strong></p>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted text-center">Belum ada data dana masjid</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Agenda Kegiatan -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-calendar-alt"></i> Agenda Kegiatan Mendatang
                    </div>
                    <div class="card-body">
                        <?php if (count($events) > 0): ?>
                            <?php foreach($events as $event): ?>
                                <div class="event-item">
                                    <h5><?php echo htmlspecialchars($event["judul"]); ?></h5>
                                    <p>
                                        <i class="far fa-calendar"></i> 
                                        <?php 
                                            $tgl_awal = date("d M Y", strtotime($event["tgl_awal"]));
                                            $tgl_akhir = date("d M Y", strtotime($event["tgl_akhir"]));
                                            if ($tgl_awal == $tgl_akhir) {
                                                echo $tgl_awal;
                                            } else {
                                                echo $tgl_awal . " - " . $tgl_akhir;
                                            }
                                        ?>
                                    </p>
                                    <p>
                                        <i class="far fa-clock"></i> 
                                        <?php 
                                            echo date("H:i", strtotime($event["jam_awal"])) . " - " . 
                                                 date("H:i", strtotime($event["jam_akhir"])); 
                                        ?> WIB
                                    </p>
                                    <p><?php echo htmlspecialchars($event["keterangan"]); ?></p>
                                    <p class="text-muted"><small>Penanggung Jawab: <?php echo htmlspecialchars($event["nama_petugas"]); ?></small></p>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted text-center">Belum ada agenda kegiatan mendatang</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Galeri Foto -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-images"></i> Galeri Foto
            </div>
            <div class="card-body">
                <div class="row photo-gallery">
                    <?php if (count($photos) > 0): ?>
                        <?php foreach($photos as $photo): ?>
                            <div class="col-md-4 col-sm-6">
                                <img src="uploads/<?php echo htmlspecialchars($photo["file_name"]); ?>" alt="Foto Masjid" class="img-fluid">
                                <p class="text-muted">
                                    <small>Diupload pada: <?php echo date("d M Y", strtotime($photo["tgl_upload"])); ?></small><br>
                                    <small>Oleh: <?php echo htmlspecialchars($photo["uploader"]); ?></small>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12 text-center">
                            <p class="text-muted">Belum ada foto yang diupload</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Tombol Bantuan -->
        <div class="text-center mt-4 mb-4">
            <a href="#" class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#donationModal">
                <i class="fas fa-donate"></i> Donasi Sekarang
            </a>
        </div>
    </div>
    
    <!-- Modal Donasi -->
    <div class="modal fade" id="donationModal" tabindex="-1" aria-labelledby="donationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="donationModalLabel">Donasi untuk Masjid</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Silakan transfer donasi Anda ke rekening berikut:</p>
                    
                    <div class="alert alert-info">
                        <p><strong>Bank:</strong> BNI</p>
                        <p><strong>No. Rekening:</strong> 601004235</p>
                        <p><strong>Atas Nama:</strong> DIMYATHI</p>
                    </div>
                    
                    <p>Atau Anda dapat login untuk melakukan donasi secara online melalui sistem kami.</p>
                    
                    <div class="d-grid gap-2">
                        <a href="index.php" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt"></i> Login untuk Donasi
                        </a>
                        <a href="register.php" class="btn btn-secondary">
                            <i class="fas fa-user-plus"></i> Daftar Akun Baru
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container text-center">
            <p>&copy; <?php echo date("Y"); ?> Sistem Informasi Masjid. Semua hak dilindungi.</p>
        </div>
    </footer>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close connection
$conn->close();
?>